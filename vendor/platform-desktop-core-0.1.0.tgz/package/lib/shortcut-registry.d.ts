import type { EvidenceSink } from './evidence.js';
/** Desktop Core 使用的最小系统快捷键端口，隐藏 Electron globalShortcut。 */
export interface ShortcutPlatformPort {
    /** 向系统申请全局快捷键。返回值只表示系统是否接受了申请。 */
    register(accelerator: string, callback: () => void): boolean;
    /** 确认快捷键当前确实由本应用占用。 */
    isRegistered(accelerator: string): boolean;
    /** 释放本应用占用的快捷键。 */
    unregister(accelerator: string): void;
}
/** Core 读取和保存所有插件快捷键偏好的窄存储接口。 */
export interface ShortcutSettingsStore {
    read(id: string): string | undefined;
    write(id: string, accelerator: string): void;
    delete(id: string): void;
}
export type ShortcutStatus = 'registered' | 'conflict' | 'unavailable';
export type ShortcutFailureReason = 'internal-conflict' | 'external-or-system-conflict' | 'unsupported';
export interface ShortcutRequest {
    readonly id: string;
    readonly pluginId: string;
    readonly pluginName: string;
    readonly commandName: string;
    readonly defaultAccelerator: string;
    readonly onTrigger: () => void;
}
export interface ShortcutSnapshot {
    readonly id: string;
    readonly pluginId: string;
    readonly pluginName: string;
    readonly commandName: string;
    readonly defaultAccelerator: string;
    /** 当前正在尝试或已经注册的 Electron accelerator。 */
    readonly accelerator: string;
    readonly status: ShortcutStatus;
    readonly reason?: ShortcutFailureReason;
}
export interface ShortcutRegistration {
    readonly snapshot: ShortcutSnapshot;
    dispose(): void;
}
export interface ShortcutUpdateResult {
    /** 新组合是否已经替换成功。 */
    readonly applied: boolean;
    /** 用户本次提交的组合；失败时用于界面说明哪一次尝试冲突。 */
    readonly requestedAccelerator: string;
    /** 更新后的实际状态；失败时仍是原来可用的状态。 */
    readonly snapshot: ShortcutSnapshot;
    /** 失败时记录用户刚才尝试的组合，供统一设置页直接说明冲突。 */
    readonly attempt?: ShortcutSnapshot;
}
/**
 * Desktop Core 的快捷键唯一注册入口。
 *
 * 这里把“内部冲突”和“系统/其他应用冲突”分开，前者不调用系统 API，后者以系统真实
 * 返回为准。注册失败是一个可展示的能力状态，不是整个插件启动失败。
 */
export declare class ShortcutRegistry {
    #private;
    constructor(options: {
        readonly port: ShortcutPlatformPort;
        readonly settings: ShortcutSettingsStore;
        readonly evidence?: EvidenceSink;
    });
    /** 注册一个插件桌面命令；已存在的同 ID 绑定会先释放。 */
    register(request: ShortcutRequest): ShortcutRegistration;
    /** 返回某个插件快捷键的最新状态。 */
    get(id: string): ShortcutSnapshot | undefined;
    /** 返回当前生命周期内真实注册过的命令，供 DSH 快捷键中心分组展示。 */
    list(): readonly ShortcutSnapshot[];
    /**
     * 尝试替换快捷键。新组合注册成功后才释放旧组合；因此冲突不会造成原快捷键丢失。
     */
    update(id: string, requestedAccelerator: string): ShortcutUpdateResult;
    /** 恢复注册定义中的默认组合；成功后才删除用户自定义值。 */
    reset(id: string): ShortcutUpdateResult;
    /** 订阅状态变化；调用方停用时必须释放返回的订阅器。 */
    subscribe(listener: () => void): () => void;
    /** 释放一个插件持有的系统快捷键和注册状态。 */
    dispose(id: string): void;
    /** 应用退出或 Core 关闭时释放全部快捷键。 */
    disposeAll(): void;
}
/** 基于文件的快捷键配置存储；只保存用户成功应用过的快捷键。 */
export declare class FileShortcutSettingsStore implements ShortcutSettingsStore {
    #private;
    constructor(filePath: string);
    read(id: string): string | undefined;
    write(id: string, accelerator: string): void;
    delete(id: string): void;
}
