/** 证据记录允许的可序列化值，不包含用户正文和 Secret。 */
export type EvidenceValue = string | number | boolean | null;
export interface EvidenceSink {
    /** 写入一条结构化诊断事件。 */
    record(event: string, details?: Readonly<Record<string, EvidenceValue>>): void;
}
export declare function createEvidenceSink(userData: string, environment?: NodeJS.ProcessEnv): EvidenceSink;
