/** activation 所拥有资源的异步或同步回收函数。 */
export type ActivationDisposer = () => void | Promise<void>;
/** 异步结果在 generation 仍有效时才允许提交。 */
export type CompletionOutcome = "applied" | "stale";
/**
 * 一次 activation generation 的资源所有权边界。
 *
 * dispose 会先让 generation 失效，再按资源注册的逆序回收，避免晚到事件继续产生副作用。
 */
export declare class ActivationLease {
    #private;
    readonly generation: string;
    constructor(generation: string);
    get active(): boolean;
    /** 注册由该 generation 独占的资源；失效后禁止继续接管资源。 */
    own(disposer: ActivationDisposer): void;
    /** 包装事件回调，只让有效 generation 产生副作用。 */
    guard<Args extends readonly unknown[]>(callback: (...args: Args) => void): (...args: Args) => void;
    /** 等待异步结果并在提交前检查 generation，过期结果返回 stale。 */
    applyCompletion<T>(operation: Promise<T>, apply: (value: T) => void): Promise<CompletionOutcome>;
    /** 使 generation 失效并按注册逆序回收全部资源，重复调用共享同一 Promise。 */
    dispose(): Promise<void>;
}
