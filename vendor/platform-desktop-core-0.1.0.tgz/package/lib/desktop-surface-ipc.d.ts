import type { BrowserWindow, IpcMain, WebContents } from 'electron';
import type { DesktopSurfaceManager } from './desktop-surface-manager.js';
import { type DesktopSurfaceOpenOptions } from './desktop-surface-contract.js';
export declare const DESKTOP_SURFACE_IPC_CHANNEL = "desktop:surface";
type DesktopSurfaceIpcRequest = {
    readonly op: 'open' | 'toggle';
    readonly id: string;
    readonly options?: DesktopSurfaceOpenOptions;
} | {
    readonly op: 'resize';
    readonly id: string;
    readonly size: {
        readonly width: number;
        readonly height: number;
    };
} | {
    readonly op: 'close';
    readonly id: string;
} | {
    readonly op: 'open-main-session';
    readonly sessionId: string;
} | {
    readonly op: 'capabilities';
};
/** 为受信 DSH/插件 Renderer 暴露 Surface 的窄 bridge，发送窗口必须由 Core 管理。 */
export declare function registerDesktopSurfaceIpc(options: {
    readonly ipcMain: IpcMain;
    readonly surfaceManager: DesktopSurfaceManager;
    readonly openMainSession: (sessionId: string) => Promise<void>;
    readonly trustedWindows: readonly BrowserWindow[];
    readonly resolveWindow: (contents: WebContents) => BrowserWindow | null;
}): () => void;
export declare function parseDesktopSurfaceRequest(value: unknown): DesktopSurfaceIpcRequest;
export {};
