import { EventEmitter } from "node:events";
import type { RuntimeGenerationManager, RuntimeGeneration } from "./generation-manager.js";
import { DshSupervisor } from "./dsh-supervisor.js";
export interface DshRuntimeControllerOptions {
    /** 可选的 generation 持久化与切换管理器。 */
    readonly generationManager?: RuntimeGenerationManager;
    /** 为目标 generation 创建独立监督器。 */
    readonly createSupervisor: (generation: RuntimeGeneration | undefined) => DshSupervisor;
}
export interface DshActivationFailedEvent {
    /** 激活失败的根因。 */
    readonly cause: Error;
    /** 当前运行实例已恢复时的旧 URL。 */
    readonly restoredUrl?: URL;
}
export declare class DshRuntimeController extends EventEmitter {
    #private;
    constructor(options: DshRuntimeControllerOptions);
    /** 选择启动 generation 并启动对应监督器。 */
    start(): Promise<URL>;
    /** 停止当前监督器并清除 ready 引用。 */
    stop(): Promise<void>;
    /** 重启当前 generation；尚未启动时退化为 start。 */
    restart(): Promise<URL>;
    /** 切换到目标 generation；失败时恢复旧实例并发出 activation-failed。 */
    activate(generationId: string): Promise<URL>;
    /** 激活 generation manager 记录的上一版本。 */
    rollback(): Promise<URL>;
}
