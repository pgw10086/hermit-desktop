import { type GenerationStateStore, type RuntimeActivationState } from "./generation-state-store.js";
export interface RuntimeGenerationManifest {
    /** manifest schema 版本。 */
    readonly schemaVersion: 1;
    /** generation 稳定身份，与目录名一致。 */
    readonly generationId: string;
    /** Product Desktop runtime 版本。 */
    readonly runtimeVersion: string;
    /** bundled Node 版本。 */
    readonly nodeVersion: string;
    /** DSH 版本。 */
    readonly dshVersion: string;
    /** 上游 DSH provenance 信息。 */
    readonly dshUpstream: DshUpstreamCohort;
    /** 数据 schema epoch，跨 epoch 不能直接切换。 */
    readonly dataEpoch: number;
}
export interface DshUpstreamCohort {
    /** 上游仓库地址。 */
    readonly repository: string;
    /** 上游 tag。 */
    readonly tag: string;
    /** 上游精确 commit。 */
    readonly commit: string;
    /** 实际包版本。 */
    readonly packageVersion: string;
    /** 上游源码快照路径。 */
    readonly snapshotPath: string;
    /** 源码快照校验和。 */
    readonly snapshotChecksum: string;
}
export interface RuntimeGeneration {
    /** generation 制品根目录。 */
    readonly root: string;
    /** 已校验的 generation manifest。 */
    readonly manifest: RuntimeGenerationManifest;
}
export interface GenerationSwitchOperations {
    /** 停止当前 committed runtime。 */
    stopCurrent(): Promise<void>;
    /** 启动候选 generation。 */
    startGeneration(generation: RuntimeGeneration): Promise<void>;
}
export declare class RuntimeGenerationCatalog {
    #private;
    constructor(roots: readonly string[]);
    /** 查找并校验唯一 generation 制品。 */
    get(generationId: string): RuntimeGeneration;
}
export declare class RuntimeGenerationManager {
    #private;
    constructor(options: {
        readonly catalog: RuntimeGenerationCatalog;
        readonly store: GenerationStateStore;
        readonly initialGeneration: string;
    });
    /** 读取或建立 committed generation 状态。 */
    initialize(): RuntimeActivationState;
    /** 启动时清理未完成 pending 状态，并返回 committed generation。 */
    selectStartupGeneration(): RuntimeGeneration;
    /** 按 prepared -> trial -> committed 阶段切换 generation，失败时恢复旧实例。 */
    activate(candidateId: string, operations: GenerationSwitchOperations): Promise<RuntimeGeneration>;
    rollback(operations: GenerationSwitchOperations): Promise<RuntimeGeneration>;
}
export declare function parseGenerationManifest(value: unknown): RuntimeGenerationManifest;
