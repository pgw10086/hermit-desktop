import { type DesktopNotificationEvent, type DesktopNotificationInput, type DesktopNotificationResult, type DesktopNotificationStatus, type NativeNotificationFactory } from './desktop-capabilities-contract.js';
/** 将 Electron Notification 限制为可替换、可移除、可观察的窄能力。 */
export declare class DesktopNotificationService {
    #private;
    constructor(factory: NativeNotificationFactory);
    status(): DesktopNotificationStatus;
    show(owner: object, input: DesktopNotificationInput, onEvent: (event: DesktopNotificationEvent) => void): DesktopNotificationResult;
    remove(owner: object, id: string): DesktopNotificationResult;
    disposeOwner(owner: object): void;
    /** DSH generation 重启时关闭当前 generation 的通知，但保留 Core facade 可再次使用。 */
    clear(): void;
    dispose(): void;
    private removeEntry;
}
