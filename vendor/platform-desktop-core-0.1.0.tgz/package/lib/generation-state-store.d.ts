/** generation 切换的持久化阶段。 */
export type PendingGenerationPhase = "prepared" | "trial";
export interface RuntimeActivationState {
    /** 状态文件 schema 版本。 */
    readonly schemaVersion: 1;
    /** 当前已提交且启动时优先使用的 generation。 */
    readonly committedGeneration: string;
    /** 上一个 committed generation，用于回滚。 */
    readonly previousGeneration?: string;
    /** 正在试运行的候选 generation。 */
    readonly pendingGeneration?: string;
    /** 候选切换当前所处阶段。 */
    readonly pendingPhase?: PendingGenerationPhase;
    /** Canonical 数据 schema epoch。 */
    readonly dataEpoch: number;
}
export interface GenerationStateStore {
    /** 读取主状态或有效 backup。 */
    read(): RuntimeActivationState | undefined;
    /** 校验并原子写入状态。 */
    write(state: RuntimeActivationState): void;
}
/** 校验 generation 身份可安全用于目录和状态文件。 */
export declare function assertGenerationId(value: string): string;
/** 校验外部状态 JSON，并保证 pending generation 与 phase 成对存在。 */
export declare function parseActivationState(value: unknown): RuntimeActivationState;
export declare class FileGenerationStateStore implements GenerationStateStore {
    #private;
    constructor(statePath: string);
    /** 读取主状态；主文件损坏时回退到最后一个有效 backup。 */
    read(): RuntimeActivationState | undefined;
    /** 以临时文件和 backup 保护方式原子写入 generation 状态。 */
    write(state: RuntimeActivationState): void;
}
