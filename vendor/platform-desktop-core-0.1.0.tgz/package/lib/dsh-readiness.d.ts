/** 从 DSH 输出中提取并校验 loopback Web URL。 */
export declare function extractDshWebUrl(output: string): URL | undefined;
/** 校验 URL 必须是本机 loopback HTTP，拒绝凭据和非标准主机。 */
export declare function validateDshWebUrl(value: string): URL;
export interface HttpReadyOptions {
    /** 等待 HTTP 可用的总时长。 */
    readonly timeoutMs: number;
    /** 连续探测之间的间隔。 */
    readonly intervalMs?: number;
    /** 注入的 fetch 实现，便于资格测试使用 fixture。 */
    readonly fetcher?: typeof fetch;
}
/** 通过真实 HTTP 探测确认 DSH 已可服务，而不是只依赖启动日志。 */
export declare function waitForHttpReady(url: URL, options: HttpReadyOptions): Promise<void>;
