import type { NativeNotificationFactory } from './desktop-capabilities-contract.js';
/** Electron 适配只存在于 Desktop Core；这里把原生对象收窄成能力契约。 */
export declare function createElectronNotificationFactory(): NativeNotificationFactory;
