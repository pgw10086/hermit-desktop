import { type DesktopDeadlineFiredEvent, type DesktopDeadlineInput, type DesktopDeadlineResult } from './desktop-capabilities-contract.js';
export interface DeadlineClock {
    now(): number;
    setTimeout(callback: () => void, delayMs: number): ReturnType<typeof setTimeout>;
    clearTimeout(handle: ReturnType<typeof setTimeout>): void;
}
/**
 * 只等待调用方已经算好的绝对时刻。它不保存 Reminder 规则，也不理解重复、事项或时区。
 */
export declare class DesktopDeadlineService {
    #private;
    constructor(clock?: DeadlineClock);
    arm(owner: object, input: DesktopDeadlineInput, onFire: (event: DesktopDeadlineFiredEvent) => void): DesktopDeadlineResult;
    cancel(owner: object, id: string): DesktopDeadlineResult;
    disposeOwner(owner: object): void;
    /** DSH generation 重启时撤销当前 generation 的等待，但保留 Core facade 可再次使用。 */
    clear(): void;
    dispose(): void;
    private schedule;
    private clearEntry;
}
