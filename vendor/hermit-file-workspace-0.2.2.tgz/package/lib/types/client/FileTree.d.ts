import { type DragEvent, type ReactNode } from 'react';
import type { FileSummary, FolderRecord, Selection } from './contracts.js';
interface FileTreeProps {
    /** Host 当前投影的文件夹、活动文件和废纸篓。 */
    readonly snapshot: {
        readonly folders: readonly FolderRecord[];
        readonly files: readonly FileSummary[];
        readonly trash: readonly FileSummary[];
    };
    /** 当前导航选择。 */
    readonly selection: Selection;
    /** 各文件夹及废纸篓的展开状态。 */
    readonly expanded: Readonly<Record<string, boolean>>;
    /** 当前文件名搜索词。 */
    readonly query: string;
    /** 当前拖放目标身份。 */
    readonly dragTarget: string | 'trash' | null;
    /** 导入完成后需要高亮的文件身份。 */
    readonly highlightIds: ReadonlySet<string>;
    /** 更新搜索词。 */
    readonly onQueryChange: (query: string) => void;
    /** 创建快速记事。 */
    readonly onCreateNote: () => void;
    /** 打开系统文件选择器。 */
    readonly onAdd: () => void;
    /** 打开新建文件夹流程。 */
    readonly onCreateFolder: () => void;
    /** 请求删除空文件夹。 */
    readonly onDeleteFolder: (id: string) => void;
    /** 折叠全部文件夹。 */
    readonly onCollapseAll: () => void;
    /** 选择文件夹。 */
    readonly onSelectFolder: (id: string) => void;
    /** 选择文件并打开编辑器。 */
    readonly onSelectFile: (id: string) => void;
    /** 切换废纸篓展开状态。 */
    readonly onToggleTrash: () => void;
    /** 恢复废纸篓文件。 */
    readonly onRestore: (id: string) => void;
    /** 永久删除单个废纸篓文件。 */
    readonly onPurge: (id: string) => void;
    /** 清空废纸篓。 */
    readonly onPurgeTrash: () => void;
    /** 更新拖放目标。 */
    readonly onDragTarget: (target: string | 'trash' | null) => void;
    /** 接收文件拖放并提交导入。 */
    readonly onDropFiles: (event: DragEvent<HTMLElement>, destination: string | 'trash') => void;
}
/** 文件夹、文件和废纸篓导航树；不拥有文件的 Canonical 状态。 */
export declare function FileTree(props: FileTreeProps): ReactNode;
export {};
//# sourceMappingURL=FileTree.d.ts.map