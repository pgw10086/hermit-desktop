import { type ReactNode } from 'react';
import type { FileReadResult, FileSummary, SaveStatus } from './contracts.js';
interface FileEditorProps {
    /** 当前选中的文件。 */
    readonly file: FileSummary | undefined;
    /** 当前文件读取结果及 revision。 */
    readonly read: FileReadResult | undefined;
    /** 保存状态。 */
    readonly saveStatus: SaveStatus;
    /** 是否处于窄窗口布局。 */
    readonly compact: boolean;
    /** 收起文件树。 */
    readonly onCollapseTree: () => void;
    /** 显示文件树。 */
    readonly onShowTree: () => void;
    /** 更新编辑器正文。 */
    readonly onChange: (content: string) => void;
    /** 重新读取当前文件。 */
    readonly onRetry: () => void;
    /** 当前是否有可用的对话 projection。 */
    readonly projectionAvailable: boolean;
    /** 请求将文件投影插入对话。 */
    readonly onProjection: () => void;
    /** 打开移动文件流程。 */
    readonly onMove: () => void;
    /** 将当前文件移入废纸篓。 */
    readonly onTrash: () => void;
}
/** 文件编辑器和通用文件信息面板；保存由上层端口负责。 */
export declare function FileEditor(props: FileEditorProps): ReactNode;
export {};
//# sourceMappingURL=FileEditor.d.ts.map