import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/** File Workspace Client 需要的 slot、布局和公开连接服务。 */
export declare const inject: string[];
/** 注册文件工作区 Product Surface 和 Core-owned 产品入口。 */
export declare function apply(ctx: ClientContext): void;
declare const _default: {
    inject: string[];
    apply: typeof apply;
};
export default _default;
//# sourceMappingURL=index.d.ts.map