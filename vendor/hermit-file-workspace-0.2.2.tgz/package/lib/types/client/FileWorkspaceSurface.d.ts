import { type ReactNode } from 'react';
import type { FileWorkspacePort } from './contracts.js';
export interface FileWorkspaceSurfaceProps {
    /** Host 提供的文件工作区端口。 */
    readonly port: FileWorkspacePort;
    /** 关闭 Product Surface。 */
    readonly onClose: () => void;
}
/** 文件工作区 Product Surface；统一拥有选择、导入、编辑和模态流程状态。 */
export declare function FileWorkspaceSurface({ port, onClose }: FileWorkspaceSurfaceProps): ReactNode;
//# sourceMappingURL=FileWorkspaceSurface.d.ts.map