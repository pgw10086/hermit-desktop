import type { ClientConnectionRpc } from '@deepseek-ai/dsh-client-connection/client';
import type { FileWorkspacePort } from './contracts.js';
/** 创建文件工作区 Client 端口，并以最新 Host 快照驱动订阅者。 */
export declare function createFileWorkspacePort(rpc: ClientConnectionRpc): FileWorkspacePort;
//# sourceMappingURL=port.d.ts.map