import type { Context } from '@deepseek-ai/cordis';
import { z } from 'zod';
import type { FileReadResult, FileWorkspaceRpcResponse, ImportFileInput, WorkspaceSnapshot } from './types.js';
/** File Workspace 的唯一持久化 writer。所有跨表变更都先写 operations journal，重启时收敛半成品。 */
export declare class FileWorkspaceService {
    private readonly domain;
    private constructor();
    static open(ctx: Context): Promise<FileWorkspaceService>;
    close(): Promise<void>;
    snapshot(): Promise<WorkspaceSnapshot>;
    read(fileId: string): Promise<FileReadResult>;
    createNote(): Promise<FileWorkspaceRpcResponse>;
    createFolder(name: string): Promise<FileWorkspaceRpcResponse>;
    deleteFolder(folderId: string): Promise<FileWorkspaceRpcResponse>;
    moveFile(fileId: string, destinationFolderId: string): Promise<FileWorkspaceRpcResponse>;
    trashFile(fileId: string): Promise<FileWorkspaceRpcResponse>;
    restoreFile(fileId: string): Promise<FileWorkspaceRpcResponse>;
    purgeFile(fileId: string): Promise<FileWorkspaceRpcResponse>;
    purgeTrash(): Promise<FileWorkspaceRpcResponse>;
    saveMarkdown(fileId: string, expectedRevisionId: string, content: string): Promise<FileWorkspaceRpcResponse>;
    importFile(input: ImportFileInput): Promise<FileWorkspaceRpcResponse>;
    setLastOpen(fileId: string): Promise<FileWorkspaceRpcResponse>;
    private table;
    private folders;
    private files;
    private filesInFolder;
    private revisionsFor;
    private blobForCurrent;
    private requireFolder;
    private requireActiveFile;
    private createManaged;
    private commitRevision;
    private ensureRootAndQuickNotes;
    private reconcileOperations;
}
export declare const fileWorkspaceRequestSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    operation: z.ZodLiteral<"snapshot">;
}, z.core.$strip>, z.ZodObject<{
    operation: z.ZodLiteral<"read">;
    fileId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    operation: z.ZodLiteral<"create-note">;
}, z.core.$strip>, z.ZodObject<{
    operation: z.ZodLiteral<"create-folder">;
    name: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    operation: z.ZodLiteral<"delete-folder">;
    folderId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    operation: z.ZodLiteral<"move-file">;
    fileId: z.ZodString;
    destinationFolderId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    operation: z.ZodLiteral<"trash-file">;
    fileId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    operation: z.ZodLiteral<"restore-file">;
    fileId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    operation: z.ZodLiteral<"purge-file">;
    fileId: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    operation: z.ZodLiteral<"purge-trash">;
}, z.core.$strip>, z.ZodObject<{
    operation: z.ZodLiteral<"save-markdown">;
    fileId: z.ZodString;
    expectedRevisionId: z.ZodString;
    content: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    operation: z.ZodLiteral<"import-file">;
    input: z.ZodObject<{
        name: z.ZodString;
        mediaType: z.ZodString;
        data: z.ZodString;
        destinationFolderId: z.ZodString;
        mode: z.ZodUnion<readonly [z.ZodLiteral<"create">, z.ZodLiteral<"replace">, z.ZodLiteral<"skip">]>;
    }, z.core.$strip>;
}, z.core.$strip>, z.ZodObject<{
    operation: z.ZodLiteral<"set-last-open">;
    fileId: z.ZodString;
}, z.core.$strip>], "operation">;
export type ParsedFileWorkspaceRequest = z.infer<typeof fileWorkspaceRequestSchema>;
//# sourceMappingURL=service.d.ts.map