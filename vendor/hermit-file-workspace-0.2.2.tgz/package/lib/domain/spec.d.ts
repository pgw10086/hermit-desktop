import { z } from 'zod';
import type { FileRecord, FolderRecord, ManagedBlobRecord, OperationRecord, RevisionRecord } from './types.js';
/** File Workspace 的唯一领域注册；表结构和 global 状态由此作为持久化真源。 */
export declare const FILE_WORKSPACE_DOMAIN: {
    readonly name: "file_workspace";
    readonly version: 1;
    readonly global: {
        readonly schema: z.ZodObject<{
            initialized: z.ZodBoolean;
            lastOpenFileId: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>;
        readonly initial: {
            readonly initialized: false;
            readonly lastOpenFileId: undefined;
        };
    };
    readonly tables: {
        readonly folders: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, FolderRecord>;
        readonly files: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, FileRecord>;
        readonly blobs: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, ManagedBlobRecord>;
        readonly revisions: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, RevisionRecord>;
        readonly operations: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, OperationRecord>;
    };
};
/** 快速笔记固定目录 ID，跨 UI、导入和恢复流程必须保持稳定。 */
export declare const QUICK_NOTES_FOLDER_ID = "quick-notes";
/** 工作区根目录 ID，所有用户目录都从该节点开始。 */
export declare const ROOT_FOLDER_ID = "root";
//# sourceMappingURL=spec.d.ts.map