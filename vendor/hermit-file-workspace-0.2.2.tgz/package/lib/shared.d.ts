/** File Workspace Host/Client 共用的 RPC 通道名，修改需同步两端注册。 */
export declare const RPC_CHANNEL = "/file-workspace";
//# sourceMappingURL=shared.d.ts.map