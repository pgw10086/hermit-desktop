import type { Context } from '@deepseek-ai/cordis';
import { RPC_CHANNEL } from './shared.js';
/** File Workspace Host 需要的持久化和公开连接服务。 */
export declare const inject: string[];
/** Host 入口只暴露公开 Connection RPC，不让文件系统路径或私有 DSH 路由穿过边界。 */
export declare function apply(ctx: Context): void;
declare const _default: {
    inject: string[];
    apply: typeof apply;
};
export default _default;
export { RPC_CHANNEL };
//# sourceMappingURL=index.d.ts.map