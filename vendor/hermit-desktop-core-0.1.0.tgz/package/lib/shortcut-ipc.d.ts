import type { BrowserWindow, IpcMain, WebContents } from 'electron';
import type { ShortcutRegistry } from './shortcut-registry.js';
/** DSH 主窗口读取 Desktop Core 快捷键目录所用的独立 IPC 通道。 */
export declare const DESKTOP_SHORTCUT_IPC_CHANNEL = "hermit:desktop-shortcuts";
/** 给受信 DSH 主窗口注册快捷键目录 facade，并在目录变化时发送无正文通知。 */
export declare function registerDesktopShortcutIpc(options: {
    readonly ipcMain: IpcMain;
    readonly registry: ShortcutRegistry;
    readonly mainWindow: BrowserWindow;
    readonly resolveWindow: (contents: WebContents) => BrowserWindow | null;
}): () => void;
