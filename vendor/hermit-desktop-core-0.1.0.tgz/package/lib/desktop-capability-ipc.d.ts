import type { BrowserWindow, IpcMain, WebContents } from 'electron';
import { type DesktopDeadlineInput, type DesktopNotificationInput } from './desktop-capabilities-contract.js';
import type { DesktopDeadlineService } from './desktop-deadline-service.js';
import type { DesktopNotificationService } from './desktop-notification-service.js';
export declare const DESKTOP_DEADLINE_IPC_CHANNEL = "hermit:desktop-deadlines";
export declare const DESKTOP_NOTIFICATION_IPC_CHANNEL = "hermit:desktop-notifications";
type DeadlineRequest = {
    readonly op: 'arm';
    readonly input: DesktopDeadlineInput;
} | {
    readonly op: 'cancel';
    readonly id: string;
};
type NotificationRequest = {
    readonly op: 'status';
} | {
    readonly op: 'show' | 'replace';
    readonly input: DesktopNotificationInput;
} | {
    readonly op: 'remove';
    readonly id: string;
};
/** 将 Deadline service 限定给 DSH 主窗口和 Core 自己创建的可信 Surface。 */
export declare function registerDesktopDeadlineIpc(options: {
    readonly ipcMain: IpcMain;
    readonly service: DesktopDeadlineService;
    readonly trustedWindows: readonly BrowserWindow[];
    readonly resolveWindow: (contents: WebContents) => BrowserWindow | null;
    readonly ownsWindow?: (window: BrowserWindow) => boolean;
}): () => void;
/** 将系统通知 service 限定给 DSH 主窗口和 Core 自己创建的可信 Surface。 */
export declare function registerDesktopNotificationIpc(options: {
    readonly ipcMain: IpcMain;
    readonly service: DesktopNotificationService;
    readonly trustedWindows: readonly BrowserWindow[];
    readonly resolveWindow: (contents: WebContents) => BrowserWindow | null;
    readonly ownsWindow?: (window: BrowserWindow) => boolean;
}): () => void;
export declare function parseDeadlineRequest(value: unknown): DeadlineRequest;
export declare function parseNotificationRequest(value: unknown): NotificationRequest;
export {};
