import { spawn, type ChildProcessWithoutNullStreams } from "node:child_process";
import { EventEmitter } from "node:events";
import { waitForHttpReady } from "./dsh-readiness.js";
import type { DshCommand } from "./dsh-process-contract.js";
import type { AgentRuntimeAdapter, AgentRuntimeState } from "@platform/agent-desktop-core";
/** DSH 子进程监督器状态；unavailable 是达到重试预算后的明确终态。 */
export type DshRuntimeState = AgentRuntimeState;
export interface DshReadyEvent {
    /** 产生 ready 事件的监督 generation。 */
    readonly generation: number;
    /** 已通过 HTTP probe 的 DSH Web 地址。 */
    readonly url: URL;
}
export interface DshUnavailableEvent {
    /** 进入 unavailable 的监督 generation。 */
    readonly generation: number;
    /** 最终导致不可用的原因。 */
    readonly cause: Error;
}
export interface DshSupervisorOptions {
    /** 由上层解析好的 DSH 启动命令。 */
    readonly command: DshCommand;
    /** 等待 DSH readiness 的超时时间。 */
    readonly readyTimeoutMs?: number;
    /** 停止子进程树的超时时间。 */
    readonly shutdownTimeoutMs?: number;
    /** 崩溃恢复之间的等待时间。 */
    readonly restartDelayMs?: number;
    /** 单次启动允许的最大恢复次数。 */
    readonly maxRestarts?: number;
    /** 注入的 spawn 实现。 */
    readonly spawnProcess?: typeof spawn;
    /** 注入的 loopback readiness 探测器。 */
    readonly probe?: typeof waitForHttpReady;
    /** 注入的进程树终止器。 */
    readonly terminateTree?: (child: ChildProcessWithoutNullStreams) => Promise<void>;
}
export declare class DshSupervisor extends EventEmitter implements AgentRuntimeAdapter {
    #private;
    readonly runtimeId = "dsh";
    constructor(options: DshSupervisorOptions);
    get state(): DshRuntimeState;
    get generation(): number;
    /** 幂等启动 DSH，并在 readiness probe 通过后返回 Web URL。 */
    start(): Promise<URL>;
    /** 先完成停止，再启动新的监督 generation。 */
    restart(): Promise<URL>;
    /** 停止当前 DSH 进程树并将状态置为 stopped。 */
    stop(): Promise<void>;
}
