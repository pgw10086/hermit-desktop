import type { BrowserWindow, BrowserWindowConstructorOptions } from 'electron';
import type { DesktopFocusPort, DesktopFocusRestoreResult, DesktopSurfaceCapabilities, DesktopSurfaceCloseOptions, DesktopSurfaceDefinition, DesktopSurfaceDismissDisposition, DesktopSurfaceHandle, DesktopSurfaceOpenOptions, DesktopSurfaceSize } from './desktop-surface-contract.js';
/** Electron 在 Surface 隐藏后可能补发一次 activate；保护窗口只需覆盖这一小段事件竞态。 */
export declare const SURFACE_ACTIVATION_GUARD_MS = 500;
export interface DesktopSurfaceHostDefinition {
    readonly window: BrowserWindowConstructorOptions;
    readonly load: (window: BrowserWindow, options: DesktopSurfaceOpenOptions) => Promise<void>;
    readonly position?: (window: BrowserWindow, options: DesktopSurfaceOpenOptions) => void;
    readonly hideOnBlur?: boolean;
    readonly eagerLoad?: boolean;
    readonly onShown?: (window: BrowserWindow) => void;
    readonly onHidden?: (window: BrowserWindow) => void;
}
/**
 * Desktop Core 的窗口宿主。它只理解 Surface 的生命周期和桌面偏好，业务内容由 host loader
 * 提供；因此 Smart Clipboard、对话和后续 Product Panel 共用同一个资源管理入口。
 */
export declare class DesktopSurfaceManager {
    #private;
    constructor(options: {
        readonly createWindow: (options: BrowserWindowConstructorOptions) => BrowserWindow;
        readonly getFocusedWindow?: () => BrowserWindow | null;
        readonly focusPort?: DesktopFocusPort;
        readonly onFocusRestore?: (id: string, disposition: DesktopSurfaceDismissDisposition, result: DesktopFocusRestoreResult) => void;
        readonly onVisibilityChanged?: (id: string, visible: boolean) => void;
    });
    register(definition: DesktopSurfaceDefinition, host: DesktopSurfaceHostDefinition): () => void;
    open(id: string, options?: DesktopSurfaceOpenOptions): Promise<DesktopSurfaceHandle>;
    toggle(id: string, options?: DesktopSurfaceOpenOptions): Promise<DesktopSurfaceHandle | null>;
    resize(id: string, size: DesktopSurfaceSize): void;
    close(id: string, options?: DesktopSurfaceCloseOptions): Promise<void>;
    /** 只供 Desktop Core 内部适配器使用；插件拿到的 API 不包含窗口对象。 */
    windowFor(id: string): BrowserWindow;
    /** 判断一个 Renderer 是否属于当前 Core 管理的 Surface。 */
    ownsWindow(window: BrowserWindow): boolean;
    /** 判断是否有桌面 Surface 正在打开、可见或刚刚关闭，供 App activate 区分浮层显隐。 */
    hasActiveSurface(): boolean;
    /** 主进程退出或 owner 停用时销毁全部 Surface。 */
    disposeAll(): void;
    capabilities(): DesktopSurfaceCapabilities;
    private destroy;
    /** 优先恢复本进程窗口；没有本地窗口时才请求平台适配器恢复外部应用。 */
    private captureFocusLease;
    private disposeFocusLease;
    /** 关闭窗口后按 disposition 处理一次性焦点租约；恢复失败不阻断窗口关闭。 */
    private finishClose;
    private ensureLoaded;
    private require;
    private handle;
    private setVisible;
    private emit;
    private setSize;
    private rememberBounds;
}
