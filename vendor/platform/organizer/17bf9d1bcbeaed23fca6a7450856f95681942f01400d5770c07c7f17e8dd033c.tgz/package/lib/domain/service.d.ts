import type { Context } from '@deepseek-ai/cordis';
import type { OrganizerCommand, OrganizerCommandResult, OrganizerQuery, OrganizerSnapshot, TemporalPoint } from '../client/contracts.js';
import type { OrganizerRecord } from './types.js';
import { type CreateReminderInput } from './time.js';
export interface CreateTodoInput {
    /** 待办标题，写入前会去除首尾空白并校验长度。 */
    readonly title: string;
    /** 待办详细内容。 */
    readonly detail?: string;
    /** 用户原始输入，用于保留来源上下文。 */
    readonly originalInput?: string;
    /** 创建时附带的清单文本。 */
    readonly checklist?: readonly {
        readonly text: string;
    }[];
    /** 计划开始时间；明确执行时刻时由 AI 解析为该字段。 */
    readonly todoStart?: TemporalPoint;
    /** 最晚完成时间；只有用户表达截止语义时填写。 */
    readonly todoDue?: TemporalPoint;
    /** 创建时附带的一次性提醒。 */
    readonly reminders?: readonly CreateReminderInput[];
}
export interface CreateNoteInput {
    /** 便签标题，写入前会去除首尾空白并校验长度。 */
    readonly title: string;
    /** 便签详细内容。 */
    readonly detail?: string;
    /** 用户原始输入，用于保留来源上下文。 */
    readonly originalInput?: string;
    /** 创建时附带的一次性提醒。 */
    readonly reminders?: readonly CreateReminderInput[];
}
/** Organizer Canonical 数据的唯一写入服务，统一处理 revision、幂等和状态转换。 */
export declare class OrganizerService {
    private readonly domain;
    private constructor();
    /** 打开 Organizer 存储域；调用方负责在插件停用时关闭服务。 */
    static open(ctx: Context): Promise<OrganizerService>;
    /** 关闭存储域并释放其资源。 */
    close(): Promise<void>;
    /** 校验并创建一条待办；相同 callId 的重复调用返回原记录。 */
    createTodo(input: CreateTodoInput, callId: string): Promise<OrganizerRecord>;
    /** 校验并创建一条便签；相同 callId 的重复调用返回原记录。 */
    createNote(input: CreateNoteInput, callId: string): Promise<OrganizerRecord>;
    /** 根据查询生成统一快照，活动、搜索和回收站投影互不共享可变数组。 */
    snapshot(query?: OrganizerQuery): Promise<OrganizerSnapshot>;
    /** 执行带 revision 约束的命令，并将预期失败转换为明确结果。 */
    execute(command: OrganizerCommand): Promise<OrganizerCommandResult>;
    /** 保存新建或编辑中的事项，并处理类型转换和并发冲突。 */
    private save;
    /** 将计划中的待办标记为完成，完成后 revision 递增。 */
    private complete;
    /** 执行便签置顶、归档、取消或移入回收站等生命周期动作。 */
    private lifecycle;
    /** 从回收站恢复事项，并保留恢复前的 Canonical 状态。 */
    private restore;
    /** 永久删除回收站中的事项；活动事项不能直接走此路径。 */
    private purge;
    /** 读取并校验 revision 后应用状态转换，将业务失败转成 typed result。 */
    private updateItem;
    /** 读取当前域中的全部 Canonical 事项记录。 */
    private records;
    /** 创建事项并写入幂等调用记录，避免 Tool 重放产生重复事项。 */
    private createRecord;
    private writeChain;
    /** 让所有写操作按提交顺序执行，同时保持失败后队列可继续使用。 */
    private write;
}
//# sourceMappingURL=service.d.ts.map