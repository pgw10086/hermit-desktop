import type { OrganizerRecord, OrganizerToolCall } from './types.js';
/** Organizer 的唯一领域注册；条目和工具调用由该定义统一持久化。 */
export declare const ORGANIZER_DOMAIN: {
    readonly name: "personal_organizer";
    readonly version: 1;
    readonly tables: {
        readonly items: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, OrganizerRecord>;
        readonly tool_calls: import("@deepseek-ai/dsh-storage-domain").DomainTableSpec<string, OrganizerToolCall>;
    };
};
//# sourceMappingURL=spec.d.ts.map