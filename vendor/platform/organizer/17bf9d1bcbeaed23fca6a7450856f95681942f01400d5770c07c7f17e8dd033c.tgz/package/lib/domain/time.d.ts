import type { ReminderRuleDraft, TemporalPoint } from '../client/contracts.js';
/** AI 创建参数中的日期表达；绝对日期和相对天数只能二选一。 */
export interface TemporalExpression {
    readonly date?: string;
    readonly relativeDays?: number;
    readonly time?: string;
}
/** AI 创建参数中的一次性指定时间提醒。 */
export interface CreateReminderInput {
    readonly date?: string;
    readonly relativeDays?: number;
    readonly time: string;
    readonly sourceText?: string;
    readonly timeZone?: string;
    readonly referenceAt?: number;
}
/** 解析相对日期所需的原始用户消息时间和本地时区。 */
export interface TimeResolutionContext {
    readonly referenceAt: number;
    readonly timeZone: string;
}
/**
 * 将 AI 提取的时间事实转换为 Canonical 本地时间点。
 * 相对日期必须依赖原始用户消息时间，避免重放或异步处理时漂移。
 */
export declare function resolveTemporalExpression(input: TemporalExpression, context: TimeResolutionContext | undefined, label: string, requireTime?: boolean): TemporalPoint;
/** 校验并保留一个绝对日期。 */
export declare function validateDate(value: string, label: string): string;
/** 返回当前设备时区；它只用于本地日历日期的解析和展示。 */
export declare function systemTimeZone(): string;
/** 将一个绝对提醒输入转换为领域已有的 ReminderRule 形状。 */
export declare function toAbsoluteReminder(input: CreateReminderInput, index: number, context: TimeResolutionContext | undefined): ReminderRuleDraft;
//# sourceMappingURL=time.d.ts.map