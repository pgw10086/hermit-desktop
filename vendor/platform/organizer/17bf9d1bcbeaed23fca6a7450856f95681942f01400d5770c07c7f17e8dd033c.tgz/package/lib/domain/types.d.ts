import type { ChecklistEntry, EventTimeDraft, ItemKind, OrganizerItem, ReminderRuleDraft, TemporalPoint, TodoPriority } from '../client/contracts.js';
/** Canonical 事项状态；回收站通过 deletedAt 另行表达。 */
export type OrganizerStatus = 'active' | 'planned' | 'completed' | 'cancelled' | 'scheduled' | 'archived';
/** Canonical 事项记录；展示标签、时间文案和投影均从这里重新计算。 */
export interface OrganizerRecord {
    /** 事项稳定身份。 */
    readonly id: string;
    /** Canonical 事项类型。 */
    readonly kind: ItemKind;
    /** 标题。 */
    readonly title: string;
    /** 详细内容。 */
    readonly detail: string;
    /** 用户标签。 */
    readonly tags: readonly string[];
    /** 当前 Canonical 状态。 */
    readonly status: OrganizerStatus;
    /** 单调递增 revision，用于拒绝旧编辑覆盖新状态。 */
    readonly revision: number;
    /** 创建时间。 */
    readonly createdAt: string;
    /** 最近更新时间。 */
    readonly updatedAt: string;
    /** 创建来源展示名。 */
    readonly sourceLabel: string;
    /** 用户原始输入，不用于业务状态判断。 */
    readonly originalInput: string;
    /** 事项类型转换历史。 */
    readonly typeHistory: readonly string[];
    /** 待办完成状态。 */
    readonly completed?: boolean;
    /** 回收站时间；存在时从活动投影中排除。 */
    readonly deletedAt?: string;
    /** 是否固定。 */
    readonly pinned?: boolean;
    /** 待办优先级。 */
    readonly priority?: TodoPriority;
    /** 待办清单。 */
    readonly checklist?: readonly ChecklistEntry[];
    /** 待办开始时间。 */
    readonly todoStart?: TemporalPoint;
    /** 待办截止时间。 */
    readonly todoDue?: TemporalPoint;
    /** 日程时间。 */
    readonly eventTime?: EventTimeDraft;
    /** 日程地点。 */
    readonly location?: string;
    /** 提醒规则列表。 */
    readonly reminders: readonly ReminderRuleDraft[];
    /** 创建该事项的幂等调用身份。 */
    readonly createdByCallId?: string;
}
export interface OrganizerToolCall {
    /** Tool 调用的幂等身份。 */
    readonly callId: string;
    /** Tool 创建或更新的事项身份。 */
    readonly itemId: string;
    /** 调用完成时对应的 revision。 */
    readonly revision: number;
    /** 调用创建时间。 */
    readonly createdAt: string;
}
/** 将 Canonical 记录转换为 UI 可消费的派生投影，不改变 Canonical 状态。 */
export declare function toOrganizerItem(record: OrganizerRecord): OrganizerItem;
//# sourceMappingURL=types.d.ts.map