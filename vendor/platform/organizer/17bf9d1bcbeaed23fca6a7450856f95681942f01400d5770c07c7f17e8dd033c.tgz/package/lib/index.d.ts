import type { Context } from '@deepseek-ai/cordis';
/** Organizer Host 需要的持久化、RPC、Tool 和 Skill 服务。 */
export declare const inject: string[];
/** 注册 Organizer 的 Skill、Tool 和 Host RPC，并在 effect 结束时成组撤销。 */
export declare function apply(ctx: Context): void;
declare const _default: {
    inject: string[];
    apply: typeof apply;
};
export default _default;
export { OrganizerService } from './domain/service.js';
export { ORGANIZER_DOMAIN } from './domain/spec.js';
//# sourceMappingURL=index.d.ts.map