import type { OrganizerClientPort, OrganizerInitialIntent } from './contracts.js';
export interface OrganizerSurfaceProps {
    /** 由 Host 提供的唯一 Organizer Client 端口。 */
    readonly port: OrganizerClientPort;
    /** 打开工作面时携带的初始视图或抽屉意图。 */
    readonly initialIntent?: OrganizerInitialIntent;
    /** 关闭 Product Surface 的宿主回调。 */
    readonly onClose: () => void;
}
/** Organizer Product Surface；统一拥有视图、抽屉、草稿和未保存变更保护状态。 */
export declare function OrganizerSurface({ port, initialIntent, onClose }: OrganizerSurfaceProps): import("react").JSX.Element;
