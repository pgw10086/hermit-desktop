import type { ItemsQuery, OrganizerItem, OrganizerQuery, OrganizerSnapshot, OrganizerView } from './contracts.js';
export interface OrganizerViewsProps {
    /** 当前视图身份。 */
    readonly view: OrganizerView;
    /** Host 生成的统一投影快照。 */
    readonly snapshot: OrganizerSnapshot;
    /** 当前选中事项身份。 */
    readonly selectedItemId?: string;
    /** 最近便签区域是否展开。 */
    readonly recentNotesOpen: boolean;
    /** 切换最近便签展开状态。 */
    readonly onToggleRecentNotes: () => void;
    /** 打开事项详情抽屉。 */
    readonly onOpenItem: (itemId: string) => void;
    /** 完成待办。 */
    readonly onComplete: (item: OrganizerItem) => void;
    /** 保存列表内快速编辑内容。 */
    readonly onQuickEdit: (item: OrganizerItem, title: string, detail: string) => Promise<boolean>;
    /** 切换清单项完成状态。 */
    readonly onChecklistToggle: (item: OrganizerItem, entryId: string, completed: boolean) => Promise<boolean>;
    /** 提交搜索或回收站查询。 */
    readonly onRequest: (query: OrganizerQuery) => void;
    /** 当前事项筛选条件。 */
    readonly itemsQuery: ItemsQuery;
    /** 更新事项筛选条件。 */
    readonly onItemsQuery: (query: ItemsQuery) => void;
}
/** 根据当前视图选择唯一的领域工作面，不复制快照或业务状态。 */
export declare function OrganizerViews(props: OrganizerViewsProps): import("react").JSX.Element;
/** 展示需要持续处理的提示，不用 Toast 替代持久状态。 */
export declare function Notice({ value }: {
    readonly value?: {
        readonly tone: string;
        readonly title: string;
        readonly detail: string;
    } | undefined;
}): import("react").JSX.Element | null;
/** 宿主能力不可用时展示明确结果和重试入口。 */
export declare function UnavailableView({ message, onRetry }: {
    readonly message: string;
    readonly onRetry: () => void;
}): import("react").JSX.Element;
