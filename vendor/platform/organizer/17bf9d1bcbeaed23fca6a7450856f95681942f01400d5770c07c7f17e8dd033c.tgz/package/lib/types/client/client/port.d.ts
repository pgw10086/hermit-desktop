import type { ClientConnectionRpc } from '@deepseek-ai/dsh-client-connection/client';
import type { OrganizerClientPort } from './contracts.js';
/** 创建 Client 侧端口；只接受最新请求序列的快照，丢弃迟到响应。 */
export declare function createOrganizerPort(rpc: ClientConnectionRpc): OrganizerClientPort;
