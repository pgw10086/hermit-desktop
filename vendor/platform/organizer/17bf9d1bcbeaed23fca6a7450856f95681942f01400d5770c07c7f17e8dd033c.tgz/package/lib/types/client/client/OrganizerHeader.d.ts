import type { OrganizerView } from './contracts.js';
export interface OrganizerHeaderProps {
    readonly view: OrganizerView;
    readonly reminderAttention: boolean;
    readonly onChangeView: (view: OrganizerView) => void;
    readonly onCreate: () => void;
    readonly onSearch: () => void;
    readonly onClose: () => void;
}
export declare function OrganizerHeader({ view, reminderAttention, onChangeView, onCreate, onSearch, onClose }: OrganizerHeaderProps): import("react").JSX.Element;
