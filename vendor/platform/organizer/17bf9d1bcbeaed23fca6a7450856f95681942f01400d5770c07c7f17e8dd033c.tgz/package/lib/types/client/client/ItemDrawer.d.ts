import type { ItemDraft, ItemKind, ItemLifecycleAction, OrganizerItem } from './contracts.js';
export type DrawerState = {
    readonly mode: 'view' | 'edit';
    readonly itemId: string;
} | {
    readonly mode: 'create';
    readonly kind?: ItemKind;
};
export type DrawerIssue = {
    readonly type: 'conflict';
    readonly message: string;
    readonly latest: OrganizerItem;
} | {
    readonly type: 'error';
    readonly message: string;
};
export interface ItemDrawerProps {
    /** 当前抽屉模式和目标事项身份。 */
    readonly state: DrawerState;
    /** 当前投影中的事项；创建模式下为空。 */
    readonly item?: OrganizerItem;
    /** 编辑模式下的唯一草稿。 */
    readonly draft?: ItemDraft;
    /** 草稿是否与基线不同。 */
    readonly dirty: boolean;
    /** 是否有命令正在执行。 */
    readonly busy: boolean;
    /** 是否正在保护未保存变更。 */
    readonly guardActive: boolean;
    /** 当前需要用户处理的问题。 */
    readonly issue?: DrawerIssue;
    /** 关闭抽屉。 */
    readonly onClose: () => void;
    /** 进入编辑模式。 */
    readonly onEdit: () => void;
    /** 取消编辑并返回查看或关闭。 */
    readonly onCancelEdit: () => void;
    /** 更新唯一草稿。 */
    readonly onDraftChange: (draft: ItemDraft) => void;
    /** 保存草稿。 */
    readonly onSave: () => void;
    /** 完成当前待办。 */
    readonly onComplete: () => void;
    /** 执行事项生命周期动作。 */
    readonly onLifecycle: (action: ItemLifecycleAction) => void;
    /** 恢复回收站事项。 */
    readonly onRestore: () => void;
    /** 永久删除回收站事项。 */
    readonly onPurge: () => void;
    /** 保存草稿后继续原导航动作。 */
    readonly onGuardSave: () => void;
    /** 放弃草稿并继续原导航动作。 */
    readonly onGuardDiscard: () => void;
    /** 取消导航保护并继续编辑。 */
    readonly onGuardContinue: () => void;
    /** 接受服务端最新版本并放弃本地修改。 */
    readonly onAcceptLatest: () => void;
    /** 以最新 revision 继续本地编辑。 */
    readonly onContinueFromLatest: () => void;
}
/** 事项详情、编辑和危险操作的统一抽屉。 */
export declare function ItemDrawer(props: ItemDrawerProps): import("react").JSX.Element;
