import { z } from 'zod';
import type { OrganizerCommandResult, OrganizerQuery, OrganizerSnapshot } from '../client/contracts.js';
/** Host 接收的 Organizer RPC 请求 schema，拒绝未声明的操作和字段形状。 */
export declare const organizerRequestSchema: z.ZodUnion<readonly [z.ZodObject<{
    operation: z.ZodLiteral<"snapshot">;
    query: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
        type: z.ZodLiteral<"items">;
        kinds: z.ZodArray<z.ZodUnion<readonly [z.ZodLiteral<"note">, z.ZodLiteral<"todo">, z.ZodLiteral<"event">]>>;
        statuses: z.ZodArray<z.ZodString>;
        tags: z.ZodArray<z.ZodString>;
        sort: z.ZodUnion<readonly [z.ZodLiteral<"default">, z.ZodLiteral<"updated">]>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"search">;
        query: z.ZodString;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"trash">;
        query: z.ZodString;
    }, z.core.$strip>]>>;
}, z.core.$strip>, z.ZodObject<{
    operation: z.ZodLiteral<"command">;
    command: z.ZodUnion<readonly [z.ZodObject<{
        type: z.ZodLiteral<"save">;
        draft: z.ZodObject<{
            id: z.ZodOptional<z.ZodString>;
            kind: z.ZodUnion<readonly [z.ZodLiteral<"">, z.ZodLiteral<"note">, z.ZodLiteral<"todo">, z.ZodLiteral<"event">]>;
            title: z.ZodString;
            detail: z.ZodString;
            tags: z.ZodArray<z.ZodString>;
            pinned: z.ZodBoolean;
            priority: z.ZodUnion<readonly [z.ZodLiteral<"none">, z.ZodLiteral<"low">, z.ZodLiteral<"medium">, z.ZodLiteral<"high">]>;
            checklist: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                text: z.ZodString;
                completed: z.ZodBoolean;
            }, z.core.$strip>>;
            todoStart: z.ZodObject<{
                date: z.ZodString;
                time: z.ZodString;
            }, z.core.$strip>;
            todoDue: z.ZodObject<{
                date: z.ZodString;
                time: z.ZodString;
            }, z.core.$strip>;
            eventTime: z.ZodObject<{
                mode: z.ZodUnion<readonly [z.ZodLiteral<"date-only">, z.ZodLiteral<"all-day">, z.ZodLiteral<"timed">]>;
                startDate: z.ZodString;
                startTime: z.ZodString;
                endDate: z.ZodString;
                endTime: z.ZodString;
                hasEnd: z.ZodBoolean;
            }, z.core.$strip>;
            location: z.ZodString;
            reminders: z.ZodArray<z.ZodObject<{
                id: z.ZodString;
                mode: z.ZodUnion<readonly [z.ZodLiteral<"absolute">, z.ZodLiteral<"relative">]>;
                anchor: z.ZodUnion<readonly [z.ZodLiteral<"">, z.ZodLiteral<"todo-start">, z.ZodLiteral<"todo-due">, z.ZodLiteral<"event-start">]>;
                date: z.ZodString;
                time: z.ZodString;
                relation: z.ZodUnion<readonly [z.ZodLiteral<"before">, z.ZodLiteral<"after">]>;
                amount: z.ZodNumber;
                unit: z.ZodUnion<readonly [z.ZodLiteral<"minute">, z.ZodLiteral<"hour">, z.ZodLiteral<"day">]>;
                sourceText: z.ZodOptional<z.ZodString>;
                timeZone: z.ZodOptional<z.ZodString>;
                referenceAt: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strip>>;
            revision: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"complete">;
        itemId: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"lifecycle">;
        itemId: z.ZodString;
        revision: z.ZodNumber;
        action: z.ZodUnion<readonly [z.ZodLiteral<"pin">, z.ZodLiteral<"unpin">, z.ZodLiteral<"archive">, z.ZodLiteral<"activate">, z.ZodLiteral<"cancel">, z.ZodLiteral<"trash">]>;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"restore">;
        itemId: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strip>, z.ZodObject<{
        type: z.ZodLiteral<"purge">;
        itemId: z.ZodString;
        revision: z.ZodNumber;
    }, z.core.$strip>]>;
}, z.core.$strip>]>;
/** 从运行时 schema 推导出的 RPC 请求类型，避免静态类型与校验规则漂移。 */
export type OrganizerRpcRequest = z.infer<typeof organizerRequestSchema>;
export interface OrganizerRpcResponse {
    /** 查询成功返回的完整投影快照。 */
    readonly snapshot?: OrganizerSnapshot;
    /** 命令执行结果，预期冲突和拒绝通过 outcome 表达。 */
    readonly result?: OrganizerCommandResult;
}
/** 供 RPC 入口消费的查询输入类型。 */
export type OrganizerQueryInput = OrganizerQuery;
