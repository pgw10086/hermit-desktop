import { z } from 'zod';
/** Organizer Client 提交的条目草稿；revision 存在时表示乐观并发更新。 */
export declare const ItemDraftSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodString>;
    kind: z.ZodUnion<readonly [z.ZodLiteral<"">, z.ZodLiteral<"note">, z.ZodLiteral<"todo">, z.ZodLiteral<"event">]>;
    title: z.ZodString;
    detail: z.ZodString;
    tags: z.ZodArray<z.ZodString>;
    pinned: z.ZodBoolean;
    priority: z.ZodUnion<readonly [z.ZodLiteral<"none">, z.ZodLiteral<"low">, z.ZodLiteral<"medium">, z.ZodLiteral<"high">]>;
    checklist: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        text: z.ZodString;
        completed: z.ZodBoolean;
    }, z.core.$strip>>;
    todoStart: z.ZodObject<{
        date: z.ZodString;
        time: z.ZodString;
    }, z.core.$strip>;
    todoDue: z.ZodObject<{
        date: z.ZodString;
        time: z.ZodString;
    }, z.core.$strip>;
    eventTime: z.ZodObject<{
        mode: z.ZodUnion<readonly [z.ZodLiteral<"date-only">, z.ZodLiteral<"all-day">, z.ZodLiteral<"timed">]>;
        startDate: z.ZodString;
        startTime: z.ZodString;
        endDate: z.ZodString;
        endTime: z.ZodString;
        hasEnd: z.ZodBoolean;
    }, z.core.$strip>;
    location: z.ZodString;
    reminders: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        mode: z.ZodUnion<readonly [z.ZodLiteral<"absolute">, z.ZodLiteral<"relative">]>;
        anchor: z.ZodUnion<readonly [z.ZodLiteral<"">, z.ZodLiteral<"todo-start">, z.ZodLiteral<"todo-due">, z.ZodLiteral<"event-start">]>;
        date: z.ZodString;
        time: z.ZodString;
        relation: z.ZodUnion<readonly [z.ZodLiteral<"before">, z.ZodLiteral<"after">]>;
        amount: z.ZodNumber;
        unit: z.ZodUnion<readonly [z.ZodLiteral<"minute">, z.ZodLiteral<"hour">, z.ZodLiteral<"day">]>;
        sourceText: z.ZodOptional<z.ZodString>;
        timeZone: z.ZodOptional<z.ZodString>;
        referenceAt: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
    revision: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
