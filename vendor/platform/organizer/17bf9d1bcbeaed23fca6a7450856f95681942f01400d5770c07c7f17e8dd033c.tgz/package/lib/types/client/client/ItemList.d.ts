import type { OrganizerItem, Projection } from './contracts.js';
export interface ItemListProps {
    /** 待展示的 Organizer 投影及其状态。 */
    readonly projection: Projection<OrganizerItem>;
    /** 当前抽屉选中的事项身份。 */
    readonly selectedItemId?: string | undefined;
    /** 投影为空时的业务文案。 */
    readonly emptyLabel: string;
    /** 打开事项详情。 */
    readonly onOpen: (itemId: string) => void;
    /** 可选的完成待办动作。 */
    readonly onComplete?: (item: OrganizerItem) => void;
    /** 可选的待办快速编辑动作。 */
    readonly onQuickEdit?: (item: OrganizerItem, title: string, detail: string) => Promise<boolean>;
    /** 可选的清单项切换动作。 */
    readonly onChecklistToggle?: (item: OrganizerItem, entryId: string, completed: boolean) => Promise<boolean>;
}
/** 投影加载期间的稳定占位，不改变列表尺寸。 */
export declare function LoadingRows(): import("react").JSX.Element;
/** 根据投影状态渲染加载、不可用、部分结果或事项列表。 */
export declare function ItemList({ projection, selectedItemId, emptyLabel, onOpen, onComplete, onQuickEdit, onChecklistToggle }: ItemListProps): import("react").JSX.Element;
export declare function RetryLine({ message, onRetry }: {
    readonly message: string;
    readonly onRetry: () => void;
}): import("react").JSX.Element;
