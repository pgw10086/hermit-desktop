import type { ItemDraft, OrganizerItem } from './contracts.js';
/** 编辑事项草稿；所有字段更新都回传给 Surface 持有的唯一草稿。 */
export declare function ItemForm({ draft, original, onChange }: {
    /** 当前编辑草稿。 */
    readonly draft: ItemDraft;
    /** 正在编辑的原事项，创建模式下为空。 */
    readonly original?: OrganizerItem | undefined;
    /** 提交草稿变更。 */
    readonly onChange: (draft: ItemDraft) => void;
}): import("react").JSX.Element;
/** 判断草稿是否满足当前领域的最小保存条件。 */
export declare function draftCanSave(draft: ItemDraft | undefined): boolean;
