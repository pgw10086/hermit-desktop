/** Smart Clipboard 领域契约和动作计划的公开出口。 */
export * from './full-history.js';
export * from './actions.js';
export { inject, apply } from './host.js';
export { default } from './host.js';
//# sourceMappingURL=index.d.ts.map