import type { HistoryFilter, Retention } from '../full-history.js';
import type { ClipboardOperationResult, ClipboardWireEntry } from './api.js';
/** 将历史记录转换为列表摘要，避免在多个页面重复拼接文案。 */
export declare function entrySummary(entry: ClipboardWireEntry): string;
/** 将执行结果转换为持久的用户反馈文案。 */
export declare function operationMessage(result: ClipboardOperationResult): string;
/** 在 Client 侧对安全投影执行筛选，不改变 Host 的 Canonical 数据。 */
export declare function filterEntries(entries: readonly ClipboardWireEntry[], filter: HistoryFilter): readonly ClipboardWireEntry[];
/** 将字节数转换为紧凑的本地化容量文本。 */
export declare function formatBytes(value: number): string;
/** 将 Unix 毫秒时间戳转换为列表时间文本。 */
export declare function formatTime(value: number): string;
/** 将未知异常收窄为可展示消息。 */
export declare function errorMessage(cause: unknown): string;
/** 解析设置表单中的保留期限值，拒绝未声明的数字。 */
export declare function parseRetentionInput(value: string): Retention;
