import { type ReactNode } from 'react';
import type { ClipboardAction } from '../actions.js';
import type { ClipboardKind } from '../full-history.js';
import { type ClipboardWireEntry } from './api.js';
export interface HistoryWorkspaceProps {
    /** 当前处于历史还是废纸篓视图。 */
    readonly view: 'history' | 'trash';
    /** 当前筛选后的安全投影列表。 */
    readonly entries: readonly ClipboardWireEntry[];
    /** 当前选中记录。 */
    readonly selected: ClipboardWireEntry | undefined;
    /** 搜索词。 */
    readonly query: string;
    /** 内容类型筛选。 */
    readonly kind: ClipboardKind | undefined;
    /** 来源应用筛选。 */
    readonly sourceApplication: string;
    /** 是否仅显示固定记录。 */
    readonly pinnedOnly: boolean;
    /** 当前可选来源列表。 */
    readonly sources: readonly string[];
    /** 列表是否正在加载。 */
    readonly loading: boolean;
    /** 窄窗口下详情面板是否打开。 */
    readonly narrowDetailOpen: boolean;
    /** 更新搜索词。 */
    readonly onQueryChange: (value: string) => void;
    /** 更新类型筛选。 */
    readonly onKindChange: (value: ClipboardKind | undefined) => void;
    /** 更新来源筛选。 */
    readonly onSourceChange: (value: string) => void;
    /** 更新固定筛选。 */
    readonly onPinnedOnlyChange: (value: boolean) => void;
    /** 选择记录并打开详情。 */
    readonly onSelect: (id: string) => void;
    /** 窄窗口返回列表。 */
    readonly onBackToList: () => void;
    /** 更新固定状态。 */
    readonly onPin: (entry: ClipboardWireEntry, pinned: boolean) => void;
    /** 执行复制或粘贴。 */
    readonly onAction: (action: ClipboardAction) => void;
    /** 移入废纸篓。 */
    readonly onTrash: () => void;
    /** 从废纸篓恢复。 */
    readonly onRestore: () => void;
    /** 永久删除。 */
    readonly onPermanentDelete: () => void;
}
/** 历史列表与详情的双栏工作面，键盘导航使用同一选择状态。 */
export declare function HistoryWorkspace(props: HistoryWorkspaceProps): ReactNode;
