import { type ReactNode } from 'react';
import { type SmartClipboardClientApi } from './api.js';
/** 获取 Host API 并在能力缺失时展示明确的不可用状态。 */
export declare function SmartClipboardHistoryPage({ onClose }: {
    readonly onClose?: () => void;
}): ReactNode;
/** 剪贴板历史主页面，统一拥有筛选、选择、设置和操作反馈状态。 */
export declare function HistoryPageWithApi({ api, onClose }: {
    /** Host 注入的安全 Client API。 */
    readonly api: SmartClipboardClientApi;
    /** 返回 DSH 对话的宿主回调。 */
    readonly onClose?: () => void;
}): ReactNode;
