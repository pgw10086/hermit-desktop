import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
/** Client 需要的公开 slot 和布局服务。 */
export declare const inject: string[];
/** 注册设置页、历史 Product Surface 和桌面打开事件。 */
export declare function apply(ctx: ClientContext): void;
declare const _default: {
    inject: string[];
    apply: typeof apply;
};
export default _default;
