import { type ReactNode } from 'react';
import { type SmartClipboardSettings } from './api.js';
export interface SettingsViewProps {
    /** 最近一次成功保存的设置。 */
    readonly saved: SmartClipboardSettings;
    /** 当前正在编辑的设置草稿。 */
    readonly draft: SmartClipboardSettings;
    /** 更新设置草稿。 */
    readonly onChange: (settings: SmartClipboardSettings) => void;
    /** 保存设置。 */
    readonly onSave: () => void;
    /** 导出历史数据。 */
    readonly onExport: (includeTrash: boolean) => void;
    /** 清理非固定历史。 */
    readonly onClearHistory: () => void;
    /** 清空废纸篓。 */
    readonly onEmptyTrash: () => void;
    /** 清空全部剪贴板数据。 */
    readonly onClearAllData: () => void;
}
/** 剪贴板历史设置面板；只编辑草稿，不直接调用 Host API。 */
export declare function SettingsView(props: SettingsViewProps): ReactNode;
