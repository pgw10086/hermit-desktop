/** 默认保留的活动历史条数，不计入废纸篓。 */
export declare const DEFAULT_HISTORY_LIMIT = 100;
/** 默认允许占用的历史数据总字节数。 */
export declare const DEFAULT_TOTAL_BYTES = 1000000000;
/** 单条文本及其格式化表示允许的最大字节数。 */
export declare const MAX_TEXT_BYTES: number;
/** 单条图片允许的最大字节数。 */
export declare const MAX_IMAGE_BYTES: number;
/** 单条图片允许的最大像素数，避免解码资源失控。 */
export declare const MAX_IMAGE_PIXELS: number;
/** 单条文件列表允许包含的最大项目数。 */
export declare const MAX_FILE_ITEMS = 256;
/** 文件列表 manifest 允许的最大序列化字节数。 */
export declare const MAX_FILE_MANIFEST_BYTES: number;
/** 废纸篓记录的固定保留时长。 */
export declare const TRASH_RETENTION_MS: number;
/** 支持的剪贴板内容类型。 */
export type ClipboardKind = 'TEXT' | 'IMAGE' | 'FILE_LIST';
/** 用于阻止临时、隐私或自动生成内容进入历史的来源标记。 */
export type ClipboardMarker = 'transient' | 'concealed' | 'auto-generated';
/** 记录位于活动历史还是废纸篓。 */
export type HistoryState = 'history' | 'trash';
/** 历史记录的保留期限；forever 表示仅受容量和数量限制。 */
export type Retention = 'forever' | 30 | 90 | 365;
export interface ClipboardEntryBase {
    /** 记录稳定身份。 */
    readonly id: string;
    /** 内容类型。 */
    readonly kind: ClipboardKind;
    /** 捕获来源应用名称，无法识别时为空。 */
    readonly sourceApplication: string | null;
    /** 首次捕获时间，使用 Unix 毫秒时间戳。 */
    readonly createdAt: number;
    /** 最近一次使用时间，使用 Unix 毫秒时间戳。 */
    readonly lastUsedAt: number;
    /** 是否固定，固定记录不会被普通清理淘汰。 */
    readonly pinned: boolean;
    /** 当前存放位置。 */
    readonly state: HistoryState;
    /** 记录所有持久化表示占用的字节数。 */
    readonly byteSize: number;
    /** 进入废纸篓的时间；活动记录没有该字段。 */
    readonly trashedAt?: number;
}
export interface TextClipboardEntry extends ClipboardEntryBase {
    /** 类型收窄为文本记录。 */
    readonly kind: 'TEXT';
    /** 纯文本内容。 */
    readonly text: string;
    /** 可选的 HTML/RTF 格式化表示。 */
    readonly formatted?: {
        /** HTML 表示。 */
        readonly html?: string;
        /** RTF 表示。 */
        readonly rtf?: string;
    };
}
export interface ImageClipboardEntry extends ClipboardEntryBase {
    /** 类型收窄为图片记录。 */
    readonly kind: 'IMAGE';
    /** 图片原始字节，不保存派生缩略图作为 Canonical 内容。 */
    readonly bytes: Uint8Array;
    /** 图片像素宽度。 */
    readonly width: number;
    /** 图片像素高度。 */
    readonly height: number;
    /** 是否包含透明通道。 */
    readonly hasAlpha: boolean;
}
export interface FileListItem {
    /** 展示用文件名，不作为唯一身份。 */
    readonly displayName: string;
    /** 系统文件路径；重新读取时需重新检查是否存在。 */
    readonly path: string;
    /** 路径当前指向文件或文件夹。 */
    readonly itemType: 'file' | 'folder';
    /** 最近一次刷新时路径是否存在。 */
    readonly exists: boolean;
    /** 文件大小；文件夹或路径不可用时为空。 */
    readonly sizeBytes?: number;
}
export interface FileListClipboardEntry extends ClipboardEntryBase {
    /** 类型收窄为文件列表记录。 */
    readonly kind: 'FILE_LIST';
    /** 捕获时的文件列表快照。 */
    readonly items: readonly FileListItem[];
}
/** 三类剪贴板记录的 Canonical 联合类型。 */
export type ClipboardEntry = TextClipboardEntry | ImageClipboardEntry | FileListClipboardEntry;
export interface TextClipboardCapture {
    /** 类型收窄为文本捕获。 */
    readonly kind: 'TEXT';
    /** 平台读取到的纯文本。 */
    readonly text: string;
    /** 来源应用身份。 */
    readonly sourceApplication: string | null;
    /** 平台附带的过滤标记。 */
    readonly markers?: readonly ClipboardMarker[];
    /** 平台提供的格式化表示。 */
    readonly formatted?: TextClipboardEntry['formatted'];
    /** 平台捕获时间；缺失时由领域服务生成。 */
    readonly capturedAt?: number;
}
export interface ImageClipboardCapture {
    /** 类型收窄为图片捕获。 */
    readonly kind: 'IMAGE';
    /** 平台读取到的图片字节。 */
    readonly bytes: Uint8Array;
    /** 图片像素宽度。 */
    readonly width: number;
    /** 图片像素高度。 */
    readonly height: number;
    /** 是否包含透明通道。 */
    readonly hasAlpha: boolean;
    /** 来源应用身份。 */
    readonly sourceApplication: string | null;
    /** 平台附带的过滤标记。 */
    readonly markers?: readonly ClipboardMarker[];
    /** 平台捕获时间。 */
    readonly capturedAt?: number;
}
export interface FileListClipboardCapture {
    /** 类型收窄为文件列表捕获。 */
    readonly kind: 'FILE_LIST';
    /** 平台读取到的文件列表。 */
    readonly items: readonly FileListItem[];
    /** 来源应用身份。 */
    readonly sourceApplication: string | null;
    /** 平台附带的过滤标记。 */
    readonly markers?: readonly ClipboardMarker[];
    /** 平台捕获时间。 */
    readonly capturedAt?: number;
}
/** 平台捕获输入的联合类型。 */
export type ClipboardCapture = TextClipboardCapture | ImageClipboardCapture | FileListClipboardCapture;
/** 捕获结果；重复和跳过是预期业务结果，不是异常。 */
export type CaptureResult = {
    readonly status: 'recorded';
    readonly entry: ClipboardEntry;
} | {
    readonly status: 'duplicate';
    readonly entry: ClipboardEntry;
} | {
    readonly status: 'skipped';
    readonly reason: CaptureSkipReason;
};
/** 捕获被跳过的可观察原因。 */
export type CaptureSkipReason = 'empty' | 'marker' | 'too-large' | 'invalid-image' | 'invalid-file-list' | 'paused' | 'ignored' | 'storage-full';
export interface ClipboardRepository {
    /** 在指定存放位置寻找内容完全相同的记录。 */
    findDuplicate(candidate: ClipboardEntry, state: HistoryState): ClipboardEntry | undefined;
    /** 列出指定存放位置的全部记录。 */
    list(state: HistoryState): readonly ClipboardEntry[];
    /** 可选的持久化层搜索能力。 */
    search?(state: HistoryState, query: string): readonly ClipboardEntry[];
    /** 插入一条新记录。 */
    insert(entry: ClipboardEntry): void;
    /** 更新已有记录。 */
    update(entry: ClipboardEntry): void;
    /** 删除记录及其持久化内容。 */
    remove(id: string): void;
    /** 统计指定存放位置的记录数。 */
    count(state: HistoryState): number;
    /** 统计指定存放位置或全部记录占用的字节数。 */
    bytes(state?: HistoryState): number;
    /** 可选的物理存储压缩。 */
    compact?(): void;
}
export interface ClipboardHistoryOptions {
    /** 活动历史条数上限。 */
    readonly historyLimit?: number;
    /** 历史数据总字节上限。 */
    readonly totalBytes?: number;
    /** 历史记录保留期限。 */
    readonly retention?: Retention;
    /** 由 Core 注入的稳定 ID 生成器。 */
    readonly idFactory?: () => string;
    /** 由调用方注入的时间源，便于保持领域行为可测试。 */
    readonly now?: () => number;
    /** 是否从暂停状态开始。 */
    readonly paused?: boolean;
}
export interface HistoryFilter {
    /** 对文本或文件名执行的搜索词。 */
    readonly query?: string;
    /** 内容类型筛选。 */
    readonly kind?: ClipboardKind;
    /** 来源应用筛选。 */
    readonly sourceApplication?: string;
    /** 仅显示固定记录。 */
    readonly pinnedOnly?: boolean;
}
export interface ClipboardSettings {
    /** 活动历史条数上限。 */
    readonly historyLimit: number;
    /** 历史数据总字节上限。 */
    readonly totalBytes: number;
    /** 历史记录保留期限。 */
    readonly retention: Retention;
    /** 是否暂停捕获。 */
    readonly paused: boolean;
}
/**
 * 三类剪贴板记录共用的领域服务。持久化、系统剪贴板和平台权限都从外部注入，服务本身
 * 只决定记录、去重、保留、Trash 和管理动作，避免 Quick Panel 与 History 形成两套规则。
 */
export declare class ClipboardHistoryStore {
    #private;
    constructor(repository: ClipboardRepository, options?: ClipboardHistoryOptions);
    /** 校验、去重并写入一次捕获；容量不足和过滤均返回可观察跳过原因。 */
    capture(capture: ClipboardCapture): CaptureResult;
    /** 按过滤器返回活动历史，并保持固定项和最近使用项的排序规则。 */
    list(filter?: HistoryFilter): readonly ClipboardEntry[];
    /** 返回按最近删除时间排序的废纸篓记录。 */
    trash(): readonly ClipboardEntry[];
    /** 返回当前捕获策略快照。 */
    settings(): ClipboardSettings;
    /** 切换捕获暂停状态，不删除已有历史。 */
    setPaused(paused: boolean): void;
    /** 忽略下一次可记录的剪贴板变化；暂停期间不消耗这次一次性动作。 */
    ignoreNext(): void;
    /** 更新历史条数上限，并立即清理超出的非固定记录。 */
    setHistoryLimit(historyLimit: number): void;
    /** 更新容量上限，并立即尝试释放足够空间。 */
    setTotalBytes(totalBytes: number): void;
    /** 更新保留期限并立即清理已过期记录。 */
    setRetention(retention: Retention): void;
    /** 记录一次使用并更新最近使用时间。 */
    use(id: string): ClipboardEntry | undefined;
    /** 设置固定状态；固定记录不参与普通容量和数量清理。 */
    setPinned(id: string, pinned: boolean): ClipboardEntry | undefined;
    /** 将活动记录移入废纸篓并清除固定状态。 */
    moveToTrash(id: string): ClipboardEntry | undefined;
    /** 从废纸篓恢复记录；容量不足时保持废纸篓状态。 */
    restore(id: string): ClipboardEntry | undefined;
    /** 永久删除活动或废纸篓中的记录。 */
    permanentlyDelete(id: string): boolean;
    /** 清空活动历史中的非固定记录。 */
    clearHistory(): number;
    /** 清空活动历史和废纸篓中的全部记录。 */
    clearAllData(): number;
    /** 清空废纸篓中的全部记录。 */
    emptyTrash(): number;
    /** 按废纸篓固定期限和历史保留期限清理过期记录。 */
    purgeExpired(now?: number): number;
}
/** 仅用于领域测试和本地 fixture；生产实现由 Core 注入持久化 repository。 */
export declare class InMemoryClipboardRepository implements ClipboardRepository {
    #private;
    /** 在内存 fixture 中执行内容去重。 */
    findDuplicate(candidate: ClipboardEntry, state: HistoryState): ClipboardEntry | undefined;
    /** 返回指定状态的内存记录。 */
    list(state: HistoryState): readonly ClipboardEntry[];
    /** 插入内存记录并拒绝重复身份。 */
    insert(entry: ClipboardEntry): void;
    /** 更新已存在的内存记录。 */
    update(entry: ClipboardEntry): void;
    /** 删除内存记录。 */
    remove(id: string): void;
    /** 统计指定状态的记录数，供容量和 UI 汇总使用。 */
    count(state: HistoryState): number;
    /** 统计指定状态或全部记录的持久化字节数。 */
    bytes(state?: HistoryState): number;
}
